package com.example.utils

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import java.io.IOException
import java.io.OutputStream
import java.nio.charset.Charset
import java.util.UUID
import com.example.service.BluetoothPrintService

@SuppressLint("MissingPermission")
class BluetoothPrinterManager private constructor(private val context: Context) {

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val PREFS_NAME = "sales_printer_prefs"
        private const val KEY_PRINTER_MAC = "printer_mac"
        private const val KEY_PRINTER_NAME = "printer_name"
        private const val KEY_PRINTER_SIZE = "printer_size" // "58mm" or "80mm"
        private const val KEY_PRINTER_CODEPAGE = "printer_codepage" // "CP1256" or "UTF-8"
        
        @Volatile
        private var instance: BluetoothPrinterManager? = null
        
        fun getInstance(context: Context): BluetoothPrinterManager {
            return instance ?: synchronized(this) {
                instance ?: BluetoothPrinterManager(context.applicationContext).also { instance = it }
            }
        }
    }

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        BluetoothAdapter.getDefaultAdapter()
    }

    private val sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // Reactive State Flows for UI
    val isConnected = MutableStateFlow(false)
    val isConnecting = MutableStateFlow(false)
    val connectionStatus = MutableStateFlow("غير متصل")
    val pairedDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val discoveredDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val isScanning = MutableStateFlow(false)

    private var printService: BluetoothPrintService? = null
    private var isServiceBound = false
    private var receiverRegistered = false

    private val scope = CoroutineScope(Dispatchers.Main)

    private val serviceConnection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: android.content.ComponentName?, service: android.os.IBinder?) {
            val binder = service as? com.example.service.BluetoothPrintService.LocalBinder
            printService = binder?.getService()
            isServiceBound = true
            Log.d("BluetoothPrinter", "Service bound and connected")
            scope.launch {
                printService?.isConnected?.collect { isConnected.value = it }
            }
            scope.launch {
                printService?.isConnecting?.collect { isConnecting.value = it }
            }
            scope.launch {
                printService?.connectionStatus?.collect { connectionStatus.value = it }
            }
        }

        override fun onServiceDisconnected(name: android.content.ComponentName?) {
            printService = null
            isServiceBound = false
            Log.d("BluetoothPrinter", "Service disconnected")
        }
    }

    private val discoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            if (BluetoothDevice.ACTION_FOUND == action) {
                val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                }
                if (device != null) {
                    val name = device.name
                    if (!name.isNullOrBlank()) {
                        val currentList = discoveredDevices.value.toMutableList()
                        if (!currentList.any { it.address == device.address }) {
                            currentList.add(device)
                            discoveredDevices.value = currentList
                        }
                    }
                }
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED == action) {
                isScanning.value = false
            }
        }
    }

    init {
        updatePairedDevices()
        try {
            val intent = Intent(context, BluetoothPrintService::class.java)
            context.startService(intent)
            context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        } catch (e: Exception) {
            Log.e("BluetoothPrinter", "Failed to start/bind print service", e)
        }
    }

    fun hasBluetoothSupport(): Boolean = bluetoothAdapter != null
    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    fun updatePairedDevices() {
        if (!hasBluetoothSupport() || !isBluetoothEnabled()) {
            pairedDevices.value = emptyList()
            return
        }
        
        try {
            val bonded = bluetoothAdapter?.bondedDevices ?: emptySet()
            pairedDevices.value = bonded.toList()
        } catch (e: Exception) {
            Log.e("BluetoothPrinter", "Error getting paired devices", e)
        }
    }

    fun checkBluetoothPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun startDiscovery() {
        if (!hasBluetoothSupport() || !isBluetoothEnabled() || !checkBluetoothPermissions()) return
        
        try {
            discoveredDevices.value = emptyList()
            if (bluetoothAdapter?.isDiscovering == true) {
                bluetoothAdapter?.cancelDiscovery()
            }

            val filter = IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            }

            if (!receiverRegistered) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    context.registerReceiver(discoveryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
                } else {
                    context.registerReceiver(discoveryReceiver, filter)
                }
                receiverRegistered = true
            }

            bluetoothAdapter?.startDiscovery()
            isScanning.value = true
        } catch (e: Exception) {
            Log.e("BluetoothPrinter", "Error starting discovery", e)
        }
    }

    fun stopDiscovery() {
        try {
            if (bluetoothAdapter?.isDiscovering == true) {
                bluetoothAdapter?.cancelDiscovery()
            }
            if (receiverRegistered) {
                context.unregisterReceiver(discoveryReceiver)
                receiverRegistered = false
            }
            isScanning.value = false
        } catch (e: Exception) {
            Log.e("BluetoothPrinter", "Error stopping discovery", e)
        }
    }

    // ==========================================
    // CONNECTION MANAGEMENT
    // ==========================================
    fun connect(macAddress: String, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        if (!hasBluetoothSupport() || !isBluetoothEnabled()) {
            onResult(false, "البلوتوث غير مفعّل")
            return
        }

        val name = getSavedPrinterName() ?: macAddress
        if (printService == null) {
            val intent = Intent(context, BluetoothPrintService::class.java)
            context.startService(intent)
            context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }

        scope.launch {
            isConnecting.value = true
            connectionStatus.value = "جاري الاتصال..."
            
            var attempts = 0
            while (printService == null && attempts < 15) {
                delay(100)
                attempts++
            }

            val service = printService
            if (service != null) {
                service.connectDevice(macAddress, name) { success, msg ->
                    isConnecting.value = service.isConnecting.value
                    isConnected.value = service.isConnected.value
                    connectionStatus.value = service.connectionStatus.value
                    onResult(success, msg)
                }
            } else {
                isConnecting.value = false
                connectionStatus.value = "فشل الاتصال"
                onResult(false, "خدمة الطباعة غير متاحة حالياً")
            }
        }
    }

    fun disconnect() {
        printService?.disconnect()
        isConnected.value = false
        connectionStatus.value = "غير متصل"
    }

    // ==========================================
    // PERSISTENCE Settings
    // ==========================================
    fun savePrinterConfig(mac: String, name: String, size: String, codepage: String = "CP1256") {
        sharedPrefs.edit().apply {
            putString(KEY_PRINTER_MAC, mac)
            putString(KEY_PRINTER_NAME, name)
            putString(KEY_PRINTER_SIZE, size)
            putString(KEY_PRINTER_CODEPAGE, codepage)
            apply()
        }
    }

    fun getSavedPrinterMac(): String? = sharedPrefs.getString(KEY_PRINTER_MAC, null)
    fun getSavedPrinterName(): String? = sharedPrefs.getString(KEY_PRINTER_NAME, null)
    fun getSavedPrinterSize(): String = sharedPrefs.getString(KEY_PRINTER_SIZE, "58mm") ?: "58mm"
    fun getSavedPrinterCodepage(): String = sharedPrefs.getString(KEY_PRINTER_CODEPAGE, "CP1256") ?: "CP1256"

    fun autoReconnect() {
        val savedMac = getSavedPrinterMac()
        if (!savedMac.isNullOrBlank() && !isConnected.value && !isConnecting.value) {
            connect(savedMac)
        }
    }

    // ==========================================
    // ESC/POS COMMAND WRITERS
    // ==========================================
    fun writeBytes(bytes: ByteArray): Boolean {
        val service = printService
        if (service == null || !isConnected.value) {
            Log.e("BluetoothPrinter", "No active service or not connected")
            return false
        }
        return service.writeBytes(bytes)
    }

    fun initializePrinter() {
        writeBytes(byteArrayOf(0x1B, 0x40)) // ESC @ (initialize)
    }

    fun selectPrinterCodepage() {
        val codepage = getSavedPrinterCodepage()
        when (codepage) {
            "CP864" -> {
                // ESC t 28 (0x1C) is the standard for CP864 on most thermal printers.
                writeBytes(byteArrayOf(0x1B, 0x74, 0x1C))
            }
            "UTF-8" -> {
                // No ESC t needed or standard initialization
            }
            else -> {
                // Default CP1256 (Windows-1256): ESC t 22 (0x16)
                writeBytes(byteArrayOf(0x1B, 0x74, 0x16))
            }
        }
    }

    fun selectCodepageCP1256() {
        writeBytes(byteArrayOf(0x1B, 0x74, 0x16)) // ESC t 22 (Arabic/Windows-1256)
    }

    fun setAlignment(align: Int) {
        // ESC a n
        // n = 0: Left, n = 1: Center, n = 2: Right
        writeBytes(byteArrayOf(0x1B, 0x61, align.toByte()))
    }

    fun setTextSize(doubleSize: Boolean) {
        if (doubleSize) {
            writeBytes(byteArrayOf(0x1D, 0x21, 0x11)) // GS ! 17 (Double height + Double width)
        } else {
            writeBytes(byteArrayOf(0x1D, 0x21, 0x00)) // GS ! 0 (Normal size)
        }
    }

    fun setBold(isBold: Boolean) {
        if (isBold) {
            writeBytes(byteArrayOf(0x1B, 0x45, 0x01)) // ESC E 1 (Bold on)
        } else {
            writeBytes(byteArrayOf(0x1B, 0x45, 0x00)) // ESC E 0 (Bold off)
        }
    }

    fun feedPaper(lines: Int = 4) {
        writeBytes(byteArrayOf(0x1B, 0x64, lines.toByte())) // ESC d lines
    }

    fun cutPaper() {
        writeBytes(byteArrayOf(0x1D, 0x56, 0x41, 0x00)) // GS V A 0 (Full/Half cut paper)
    }

    fun printRawText(text: String, align: Int = 0, doubleSize: Boolean = false, isBold: Boolean = false) {
        setAlignment(align)
        setTextSize(doubleSize)
        setBold(isBold)

        val codepage = getSavedPrinterCodepage()
        val formattedText = text + "\n"

        try {
            val bytes = when (codepage) {
                "UTF-8" -> {
                    formattedText.toByteArray(Charsets.UTF_8)
                }
                "CP864" -> {
                    var finalBytes: ByteArray? = null
                    val candidateCharsets = listOf("cp864", "ibm864", "IBM864", "CP864")
                    for (charset in candidateCharsets) {
                        try {
                            if (Charset.isSupported(charset)) {
                                finalBytes = formattedText.toByteArray(Charset.forName(charset))
                                break
                            }
                        } catch (ignored: Exception) {}
                    }
                    finalBytes ?: formattedText.toByteArray(Charset.forName("windows-1256"))
                }
                else -> {
                    try {
                        formattedText.toByteArray(Charset.forName("windows-1256"))
                    } catch (e: Exception) {
                        try {
                            formattedText.toByteArray(Charset.forName("cp1256"))
                        } catch (e2: Exception) {
                            formattedText.toByteArray(Charsets.UTF_8)
                        }
                    }
                }
            }
            writeBytes(bytes)
        } catch (e: Exception) {
            Log.e("BluetoothPrinter", "Error printing text", e)
        }
    }

    // ==========================================
    // RECEIPT GENERATORS
    // ==========================================
    fun getLineWidth(): Int {
        return if (getSavedPrinterSize() == "80mm") 48 else 32
    }

    fun printTestReceipt() {
        if (!isConnected.value) return
        
        initializePrinter()
        selectPrinterCodepage()

        val width = getLineWidth()

        printRawText(ArabicPrinterHelper.alignCenter("تجربة الطباعة", width), align = 1, doubleSize = true, isBold = true)
        printRawText(ArabicPrinterHelper.alignCenter(getSavedPrinterName() ?: "طابعة البلوتوث", width), align = 1)
        printRawText(ArabicPrinterHelper.printDivider(width), align = 1)
        
        printRawText(ArabicPrinterHelper.printRow("نوع الورق", getSavedPrinterSize(), width), align = 1)
        printRawText(ArabicPrinterHelper.printRow("الترميز النشط", getSavedPrinterCodepage(), width), align = 1)
        printRawText(ArabicPrinterHelper.printRow("رقم التجربة", "789", width), align = 1)
        printRawText(ArabicPrinterHelper.printRow("الحالة", "ناجحة", width), align = 1)
        
        printRawText(ArabicPrinterHelper.printDivider(width), align = 1)
        printRawText(ArabicPrinterHelper.alignCenter("شكراً لاستخدامك نظامنا الاحترافي", width), align = 1)
        
        feedPaper()
        cutPaper()
    }

    fun printContractInvoice(
        storeName: String,
        contractNum: String,
        date: String,
        customerName: String,
        phone: String,
        productName: String,
        totalPrice: String,
        downPayment: String,
        remaining: String,
        firstDueDate: String
    ) {
        if (!isConnected.value) return
        
        initializePrinter()
        selectPrinterCodepage()

        val width = getLineWidth()

        // Print header
        printRawText(ArabicPrinterHelper.alignCenter(storeName, width), align = 1, doubleSize = true, isBold = true)
        printRawText(ArabicPrinterHelper.alignCenter("فاتورة عقد بيع بالتقسيط", width), align = 1, doubleSize = false, isBold = true)
        printRawText(ArabicPrinterHelper.printDoubleDivider(width), align = 1)

        // Metadata
        printRawText(ArabicPrinterHelper.printRow("رقم العقد", contractNum, width), align = 1)
        printRawText(ArabicPrinterHelper.printRow("التاريخ", date, width), align = 1)
        printRawText(ArabicPrinterHelper.printDivider(width), align = 1)

        // Customer Details
        printRawText(ArabicPrinterHelper.printRow("اسم العميل", customerName, width), align = 1, isBold = true)
        printRawText(ArabicPrinterHelper.printRow("رقم الهاتف", phone, width), align = 1)
        printRawText(ArabicPrinterHelper.printDivider(width), align = 1)

        // Product
        printRawText(ArabicPrinterHelper.printRow("اسم المنتج", productName, width), align = 1)
        printRawText(ArabicPrinterHelper.printDivider(width), align = 1)

        // Financial Calculations
        printRawText(ArabicPrinterHelper.printRow("السعر الكلي بالتقسيط", totalPrice, width), align = 1, isBold = true)
        printRawText(ArabicPrinterHelper.printRow("الدفعة الأولى", downPayment, width), align = 1)
        printRawText(ArabicPrinterHelper.printRow("المبلغ المتبقي", remaining, width), align = 1, isBold = true)
        printRawText(ArabicPrinterHelper.printRow("أول استحقاق", firstDueDate, width), align = 1)
        
        printRawText(ArabicPrinterHelper.printDoubleDivider(width), align = 1)
        printRawText(ArabicPrinterHelper.alignCenter("شكراً لتعاملكم معنا.", width), align = 1, isBold = true)
        
        feedPaper()
        cutPaper()
    }

    fun printPaymentReceipt(
        storeName: String,
        transactionNum: String,
        contractNum: String,
        customerName: String,
        date: String,
        amountPaid: String,
        totalPaid: String,
        remaining: String,
        nextDueDate: String
    ) {
        if (!isConnected.value) return
        
        initializePrinter()
        selectPrinterCodepage()

        val width = getLineWidth()

        // Print Header
        printRawText(ArabicPrinterHelper.alignCenter(storeName, width), align = 1, doubleSize = true, isBold = true)
        printRawText(ArabicPrinterHelper.alignCenter("وصل استلام دفعة مالية", width), align = 1, doubleSize = false, isBold = true)
        printRawText(ArabicPrinterHelper.printDoubleDivider(width), align = 1)

        // Receipt Details
        printRawText(ArabicPrinterHelper.printRow("رقم الوصل", transactionNum, width), align = 1)
        printRawText(ArabicPrinterHelper.printRow("رقم العقد", contractNum, width), align = 1)
        printRawText(ArabicPrinterHelper.printRow("اسم العميل", customerName, width), align = 1, isBold = true)
        printRawText(ArabicPrinterHelper.printRow("تاريخ الدفع", date, width), align = 1)
        printRawText(ArabicPrinterHelper.printDivider(width), align = 1)

        // Money
        printRawText(ArabicPrinterHelper.printRow("المبلغ المدفوع", amountPaid, width), align = 1, doubleSize = true, isBold = true)
        printRawText(ArabicPrinterHelper.printRow("إجمالي المسدد", totalPaid, width), align = 1)
        printRawText(ArabicPrinterHelper.printRow("المبلغ المتبقي", remaining, width), align = 1, isBold = true)
        
        if (nextDueDate.isNotEmpty()) {
            printRawText(ArabicPrinterHelper.printRow("الاستحقاق القادم", nextDueDate, width), align = 1)
        }
        
        printRawText(ArabicPrinterHelper.printDoubleDivider(width), align = 1)
        printRawText(ArabicPrinterHelper.alignCenter("شكراً لتعاملكم معنا.", width), align = 1, isBold = true)

        feedPaper()
        cutPaper()
    }
}
