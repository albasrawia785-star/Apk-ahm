package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import com.example.ui.components.NavigationItem
import com.example.ui.components.PremiumFloatingNavigationBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.filled.Print
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                // Force Layout Direction to Right-to-Left (RTL) for perfect Arabic localization
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    var showSplash by remember { mutableStateOf(true) }

                    if (showSplash) {
                        SplashScreen(onSplashFinished = { 
                            viewModel.currentScreen = AppScreen.HOME
                            showSplash = false 
                        })
                    } else {
                        MainAppContent(viewModel)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val currentScreen = viewModel.currentScreen

    // System Back Press Handler to navigate back to Home instead of exiting the app
    BackHandler(enabled = currentScreen != AppScreen.HOME) {
        when (currentScreen) {
            AppScreen.CUSTOMER_DETAILS -> {
                viewModel.currentScreen = AppScreen.CUSTOMERS
            }
            AppScreen.ADD_INSTALLMENT -> {
                if (viewModel.currentStep > 1) {
                    viewModel.currentStep--
                } else {
                    viewModel.currentScreen = AppScreen.HOME
                    viewModel.resetStepper()
                }
            }
            AppScreen.CUSTOMERS, AppScreen.ALERTS, AppScreen.SETTINGS -> {
                viewModel.currentScreen = AppScreen.HOME
            }
            else -> {
                viewModel.currentScreen = AppScreen.HOME
            }
        }
    }

    val navItems = listOf(
        NavigationItem("الرئيسية", Icons.Default.Home),
        NavigationItem("العملاء", Icons.Default.People),
        NavigationItem("التنبيهات", Icons.Default.Notifications),
        NavigationItem("الإعدادات", Icons.Default.Settings)
    )

    val selectedIndex = when (currentScreen) {
        AppScreen.HOME -> 0
        AppScreen.CUSTOMERS, AppScreen.CUSTOMER_DETAILS -> 1
        AppScreen.ALERTS -> 2
        AppScreen.SETTINGS -> 3
        else -> 0
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SoftBackground,
        topBar = {
            if (currentScreen != AppScreen.SPLASH && currentScreen != AppScreen.ADD_INSTALLMENT) {
                val stats by viewModel.dashboardStats.collectAsState()
                com.example.ui.components.PremiumTopHeader(
                    appName = "المبيعات والأقساط",
                    alertCount = stats.overdueCount + stats.dueTodayCount,
                    onAlertsClick = { viewModel.currentScreen = AppScreen.ALERTS },
                    onSearchClick = {
                        viewModel.currentScreen = AppScreen.CUSTOMERS
                    },
                    onSettingsClick = { viewModel.currentScreen = AppScreen.SETTINGS }
                )
            }
        },
        bottomBar = {
            if (currentScreen != AppScreen.SPLASH && currentScreen != AppScreen.ADD_INSTALLMENT) {
                PremiumFloatingNavigationBar(
                    selectedItem = selectedIndex,
                    onItemSelected = { idx ->
                        viewModel.currentScreen = when (idx) {
                            0 -> AppScreen.HOME
                            1 -> AppScreen.CUSTOMERS
                            2 -> AppScreen.ALERTS
                            3 -> AppScreen.SETTINGS
                            else -> AppScreen.HOME
                        }
                    },
                    items = navItems
                )
            }
        }
    ) { innerPadding ->
        // Premium transition slide/fade animations between views
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    top = innerPadding.calculateTopPadding(),
                    bottom = innerPadding.calculateBottomPadding()
                )
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn(animationSpec = tween(200)) togetherWith fadeOut(animationSpec = tween(200))
                },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    AppScreen.SPLASH -> SplashScreen {}
                    AppScreen.HOME -> HomeScreen(viewModel)
                    AppScreen.ADD_INSTALLMENT -> AddInstallmentScreen(viewModel)
                    AppScreen.CUSTOMERS -> CustomersScreen(viewModel)
                    AppScreen.CUSTOMER_DETAILS -> CustomerDetailsScreen(viewModel)
                    AppScreen.ALERTS -> AlertsScreen(viewModel)
                    AppScreen.SETTINGS -> SettingsScreen(viewModel)
                }
            }
        }
    }

    // ==========================================
    // AUTOMATIC BLUETOOTH PRINT/CANCEL PROMPTS
    // ==========================================
    val context = androidx.compose.ui.platform.LocalContext.current

    val pendingSale = viewModel.pendingContractSale
    val pendingCustomer = viewModel.pendingContractCustomer
    if (pendingSale != null && pendingCustomer != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewModel.clearPendingContractPrint() }) {
            Card(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Icon with Gold accent
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(color = RoyalGold.copy(alpha = 0.15f), shape = androidx.compose.foundation.shape.CircleShape)
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = null,
                            tint = DeepNavy,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Title
                    Text(
                        text = "طباعة فاتورة العقد",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepNavy
                        ),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    // Highlight Saved Customer
                    Text(
                        text = "تم حفظ عقد مبيعات العميل (${pendingCustomer.name}) بنجاح!",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextDark
                        ),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    // Subtitle / Prompt
                    Text(
                        text = "هل تريد طباعة الفاتورة الحرارية الخاصة بالعقد الآن عبر طابعة البلوتوث؟",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextSecondary
                        ),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // Buttons Stack (Vertical Arabic Action Design)
                    Button(
                        onClick = {
                            viewModel.printContract(context, pendingSale, pendingCustomer)
                            viewModel.clearPendingContractPrint()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "طباعة الفاتورة",
                            fontWeight = FontWeight.Bold,
                            color = androidx.compose.ui.graphics.Color.White,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedButton(
                        onClick = { viewModel.clearPendingContractPrint() },
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, BorderLight),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                    ) {
                        Text(
                            text = "إلغاء / تخطي",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }

    val pendingBill = viewModel.pendingPaymentBill
    val pendingPaySale = viewModel.pendingPaymentSale
    val pendingPayCust = viewModel.pendingPaymentCustomer
    val pendingPayBills = viewModel.pendingPaymentAllBills
    if (pendingBill != null && pendingPaySale != null && pendingPayCust != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewModel.clearPendingPaymentPrint() }) {
            Card(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Icon with Gold accent
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(color = RoyalGold.copy(alpha = 0.15f), shape = androidx.compose.foundation.shape.CircleShape)
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = null,
                            tint = DeepNavy,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Title
                    Text(
                        text = "طباعة وصل الدفع",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepNavy
                        ),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    // Highlight Saved Customer
                    Text(
                        text = "تم تسجيل الدفعة بنجاح للعميل (${pendingPayCust.name})!",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextDark
                        ),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    // Subtitle / Prompt
                    Text(
                        text = "هل تريد طباعة وصل الاستلام الحراري الخاص بهذه الدفعة الآن؟",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextSecondary
                        ),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // Buttons Stack (Vertical Arabic Action Design)
                    Button(
                        onClick = {
                            viewModel.printReceipt(context, pendingBill, pendingPaySale, pendingPayCust, pendingPayBills)
                            viewModel.clearPendingPaymentPrint()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "طباعة الوصل",
                            fontWeight = FontWeight.Bold,
                            color = androidx.compose.ui.graphics.Color.White,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedButton(
                        onClick = { viewModel.clearPendingPaymentPrint() },
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, BorderLight),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                    ) {
                        Text(
                            text = "إلغاء / تخطي",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}
