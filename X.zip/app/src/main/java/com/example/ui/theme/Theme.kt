package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val PremiumColorScheme = lightColorScheme(
    primary = DeepNavy,
    secondary = RoyalGold,
    tertiary = RoyalGold,
    background = SoftBackground,
    surface = SoftSurface,
    onPrimary = SoftSurface,
    onSecondary = TextDark,
    onBackground = TextDark,
    onSurface = TextDark,
    error = DangerRed,
    outline = BorderLight
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PremiumColorScheme,
        typography = Typography,
        content = content
    )
}

