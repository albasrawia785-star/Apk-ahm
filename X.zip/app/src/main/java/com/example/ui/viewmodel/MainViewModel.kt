package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.Customer
import com.example.data.model.InstallmentBill
import com.example.data.model.Sale
import com.example.data.repository.AppRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

enum class AppScreen {
    SPLASH, HOME, ADD_INSTALLMENT, CUSTOMERS, CUSTOMER_DETAILS, ALERTS, SETTINGS
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = AppRepository(
        db.customerDao(),
        db.saleDao(),
        db.installmentBillDao()
    )

    private val sharedPrefs = application.getSharedPreferences("sales_installments_prefs", Context.MODE_PRIVATE)

    // Store Name setting
    var storeName by mutableStateOf(sharedPrefs.getString("store_name", "متجري للمبيعات") ?: "متجري للمبيعات")
        private set

    fun updateStoreName(newName: String) {
        storeName = newName
        sharedPrefs.edit().putString("store_name", newName).apply()
    }

    // ==========================================
    // PRINTER INTEGRATION STATES & HELPERS
    // ==========================================
    var pendingContractSale by mutableStateOf<Sale?>(null)
    var pendingContractCustomer by mutableStateOf<Customer?>(null)

    var pendingPaymentBill by mutableStateOf<InstallmentBill?>(null)
    var pendingPaymentSale by mutableStateOf<Sale?>(null)
    var pendingPaymentCustomer by mutableStateOf<Customer?>(null)
    var pendingPaymentAllBills by mutableStateOf<List<InstallmentBill>>(emptyList())

    fun clearPendingContractPrint() {
        pendingContractSale = null
        pendingContractCustomer = null
    }

    fun clearPendingPaymentPrint() {
        pendingPaymentBill = null
        pendingPaymentSale = null
        pendingPaymentCustomer = null
        pendingPaymentAllBills = emptyList()
    }

    fun printContract(context: Context, sale: Sale, customer: Customer) {
        val printerManager = com.example.utils.BluetoothPrinterManager.getInstance(context)
        val totalStr = String.format(Locale.US, "%,.0f د.ع", sale.installmentPrice)
        val downStr = String.format(Locale.US, "%,.0f د.ع", sale.downPayment)
        val remainingStr = String.format(Locale.US, "%,.0f د.ع", sale.installmentPrice - sale.downPayment)
        
        printerManager.printContractInvoice(
            storeName = storeName,
            contractNum = sale.id.toString(),
            date = sale.saleDate,
            customerName = customer.name,
            phone = customer.phone,
            productName = sale.itemName,
            totalPrice = totalStr,
            downPayment = downStr,
            remaining = remainingStr,
            firstDueDate = sale.firstDueDate
        )
    }

    fun printReceipt(context: Context, bill: InstallmentBill, sale: Sale, customer: Customer, allBillsForSale: List<InstallmentBill>) {
        val printerManager = com.example.utils.BluetoothPrinterManager.getInstance(context)
        
        val paidBills = allBillsForSale.filter { it.isPaid }
        val totalPaid = paidBills.sumOf { it.amountPaid }
        val remaining = (sale.installmentPrice - totalPaid).coerceAtLeast(0.0)
        
        val nextUnpaidBill = allBillsForSale.filter { !it.isPaid }.minByOrNull { it.dueDate }
        val nextDueDateStr = nextUnpaidBill?.dueDate ?: "لا يوجد (مسدد بالكامل)"
        
        val amountPaidStr = String.format(Locale.US, "%,.0f د.ع", bill.amountPaid)
        val totalPaidStr = String.format(Locale.US, "%,.0f د.ع", totalPaid)
        val remainingStr = String.format(Locale.US, "%,.0f د.ع", remaining)
        
        printerManager.printPaymentReceipt(
            storeName = storeName,
            transactionNum = bill.id.toString(),
            contractNum = bill.saleId.toString(),
            customerName = customer.name,
            date = bill.paymentDate ?: bill.dueDate,
            amountPaid = amountPaidStr,
            totalPaid = totalPaidStr,
            remaining = remainingStr,
            nextDueDate = nextDueDateStr
        )
    }

    // Navigation State
    var currentScreen by mutableStateOf(AppScreen.HOME)
    val selectedCustomerId = MutableStateFlow<Long?>(null)

    // Data Flows
    val customers = repository.getAllCustomers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sales = repository.getAllSales().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val bills = repository.getAllBills().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and Filter State
    var customerSearchQuery by mutableStateOf("")
    var customerStatusFilter by mutableStateOf("ALL") // ALL, ACTIVE, COMPLETED
    var customerSortBy by mutableStateOf("NAME") // NAME, DATE

    // Derived statistics
    val totalCustomersCount = customers.map { it.size }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    
    val dashboardStats = combine(sales, bills) { allSales, allBills ->
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayStr = sdf.format(Date())
        val today = sdf.parse(todayStr) ?: Date()

        var totalSalesAmount = 0.0
        var totalProfits = 0.0
        var overdueCount = 0
        var dueTodayCount = 0
        var upcomingCount = 0

        allSales.forEach { sale ->
            totalSalesAmount += sale.installmentPrice
            totalProfits += (sale.installmentPrice - sale.cashPrice)
        }

        allBills.forEach { bill ->
            if (!bill.isPaid) {
                try {
                    val dueDate = sdf.parse(bill.dueDate)
                    if (dueDate != null) {
                        when {
                            dueDate.before(today) -> overdueCount++
                            dueDate.equals(today) -> dueTodayCount++
                            dueDate.after(today) && dueDate.time - today.time <= 7 * 24 * 60 * 60 * 1000L -> upcomingCount++
                        }
                    }
                } catch (e: Exception) {
                    // Ignore parsing error
                }
            }
        }

        DashboardStats(
            overdueCount = overdueCount,
            dueTodayCount = dueTodayCount,
            upcomingCount = upcomingCount,
            totalSales = totalSalesAmount,
            totalProfits = totalProfits
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardStats())

    // Selected Customer Details flow
    val selectedCustomer = selectedCustomerId
        .flatMapLatest { id ->
            if (id == null) flowOf(null)
            else repository.getCustomerByIdFlow(id)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedCustomerSales = selectedCustomerId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.getSalesByCustomerId(id)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedCustomerBills = selectedCustomerId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.getBillsByCustomerId(id)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // ==========================================
    // STEPPER STATE FOR ADDING NEW INSTALLMENT
    // ==========================================
    var currentStep by mutableStateOf(1)

    // Stage 1: Customer Details
    var stepCustomerHasGuarantor by mutableStateOf(false)
    var stepCustomerName by mutableStateOf("")
    var stepCustomerPhone by mutableStateOf("")
    var stepCustomerJob by mutableStateOf("")
    var stepCustomerNationalId by mutableStateOf("")
    var stepCustomerProvince by mutableStateOf("بغداد")
    var stepCustomerLandmark by mutableStateOf("")
    var stepCustomerRegDate by mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))

    // Guarantor details (if hasGuarantor)
    var stepGuarantorName by mutableStateOf("")
    var stepGuarantorPhone by mutableStateOf("")
    var stepGuarantorJob by mutableStateOf("")
    var stepGuarantorNationalId by mutableStateOf("")

    // Stage 2: Item Details
    var stepItemName by mutableStateOf("")
    var stepItemDescription by mutableStateOf("")

    // Stage 3: Calculations
    var stepCashPrice by mutableStateOf("")
    var stepInstallmentPrice by mutableStateOf("")
    var stepDownPayment by mutableStateOf("")
    var stepMonthsCount by mutableStateOf("12")
    var stepDueDay by mutableStateOf("1")
    var stepFirstDueDate by mutableStateOf("")

    init {
        // Set default first due date to 1 month from now
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, 1)
        stepFirstDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        stepDueDay = cal.get(Calendar.DAY_OF_MONTH).toString()

        // Boot and prepopulate database
        viewModelScope.launch {
            try {
                repository.prepopulateIfEmpty()
            } catch (e: Exception) {
                android.util.Log.e("MainViewModel", "Error prepopulating database", e)
            }
            
            // Auto-reconnect to saved Bluetooth printer on app launch
            try {
                com.example.utils.BluetoothPrinterManager.getInstance(application).autoReconnect()
            } catch (e: Exception) {
                android.util.Log.e("MainViewModel", "Error auto-reconnecting to printer", e)
            }
        }
    }

    // Reactive automated monthly installment calculation
    val stepMonthlyInstallment: Double
        get() = 0.0

    val stepRemainingAmount: Double
        get() {
            val instPrice = stepInstallmentPrice.toDoubleOrNull() ?: 0.0
            val downPay = stepDownPayment.toDoubleOrNull() ?: 0.0
            return (instPrice - downPay).coerceAtLeast(0.0)
        }

    fun resetStepper() {
        currentStep = 1
        stepCustomerHasGuarantor = false
        stepCustomerName = ""
        stepCustomerPhone = ""
        stepCustomerJob = ""
        stepCustomerNationalId = ""
        stepCustomerProvince = "بغداد"
        stepCustomerLandmark = ""
        stepCustomerRegDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

        stepGuarantorName = ""
        stepGuarantorPhone = ""
        stepGuarantorJob = ""
        stepGuarantorNationalId = ""

        stepItemName = ""
        stepItemDescription = ""

        stepCashPrice = ""
        stepInstallmentPrice = ""
        stepDownPayment = ""
        stepMonthsCount = "12"

        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, 1)
        stepFirstDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        stepDueDay = cal.get(Calendar.DAY_OF_MONTH).toString()
    }

    fun saveNewInstallment(onComplete: () -> Unit) {
        viewModelScope.launch {
            // 1. Create/Save Customer
            val customer = Customer(
                name = stepCustomerName,
                phone = stepCustomerPhone,
                job = stepCustomerJob,
                nationalId = stepCustomerNationalId,
                province = stepCustomerProvince,
                nearestLandmark = stepCustomerLandmark,
                registrationDate = stepCustomerRegDate,
                hasGuarantor = stepCustomerHasGuarantor,
                guarantorName = if (stepCustomerHasGuarantor) stepGuarantorName else "",
                guarantorPhone = if (stepCustomerHasGuarantor) stepGuarantorPhone else "",
                guarantorJob = if (stepCustomerHasGuarantor) stepGuarantorJob else "",
                guarantorNationalId = if (stepCustomerHasGuarantor) stepGuarantorNationalId else ""
            )
            val customerId = repository.insertCustomer(customer)

            // 2. Create Sale
            val cashVal = stepCashPrice.toDoubleOrNull() ?: 0.0
            val instVal = stepInstallmentPrice.toDoubleOrNull() ?: 0.0
            val downVal = stepDownPayment.toDoubleOrNull() ?: 0.0
            val dueDayVal = stepDueDay.toIntOrNull() ?: 1

            val sale = Sale(
                customerId = customerId,
                itemName = stepItemName,
                itemDescription = stepItemDescription,
                cashPrice = cashVal,
                installmentPrice = instVal,
                downPayment = downVal,
                monthsCount = 0, // No longer used
                monthlyInstallment = 0.0, // No longer used
                dueDay = dueDayVal,
                firstDueDate = stepFirstDueDate,
                saleDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                status = if (instVal - downVal <= 0.0) "COMPLETED" else "ACTIVE"
            )

            // 3. Generate Installment Bills schedule
            val billsList = mutableListOf<InstallmentBill>()
            
            // First: insert the down payment as a paid InstallmentBill (if downVal > 0)
            if (downVal > 0.0) {
                billsList.add(
                    InstallmentBill(
                        saleId = 0, // will be overwritten in repository
                        customerId = customerId,
                        billNumber = 1,
                        dueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                        amount = downVal,
                        amountPaid = downVal,
                        paymentDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                        isPaid = true,
                        notes = "الدفعة الأولى (مقدم العقد)"
                    )
                )
            }

            // Second: insert exactly ONE unpaid InstallmentBill for the next due date if Remaining > 0
            val remaining = instVal - downVal
            if (remaining > 0.0) {
                billsList.add(
                    InstallmentBill(
                        saleId = 0,
                        customerId = customerId,
                        billNumber = if (downVal > 0.0) 2 else 1,
                        dueDate = stepFirstDueDate,
                        amount = remaining,
                        amountPaid = 0.0,
                        paymentDate = null,
                        isPaid = false,
                        notes = "المتبقي المستحق"
                    )
                )
            }

            val saleId = repository.insertSale(sale, billsList)
            pendingContractSale = sale.copy(id = saleId)
            pendingContractCustomer = customer.copy(id = customerId)
            resetStepper()
            onComplete()
        }
    }

    // ==========================================
    // PAYMENT PROCESSING - NEW TRANSACTION-BASED SYSTEM
    // ==========================================
    fun addNewPayment(saleId: Long, customerId: Long, amount: Double, dateStr: String, notes: String, onError: (String) -> Unit, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val sale = repository.getSaleById(saleId) ?: return@launch
            val bills = repository.getBillsBySaleId(saleId).first()
            
            val paidBills = bills.filter { it.isPaid }
            val totalPaidBefore = paidBills.sumOf { it.amountPaid }
            val remainingBefore = sale.installmentPrice - totalPaidBefore
            
            if (amount > remainingBefore) {
                onError("قيمة الدفعة أكبر من المبلغ المتبقي")
                return@launch
            }
            
            val newBill = InstallmentBill(
                saleId = saleId,
                customerId = customerId,
                billNumber = paidBills.size + 1,
                dueDate = dateStr,
                amount = amount,
                amountPaid = amount,
                paymentDate = dateStr,
                isPaid = true,
                notes = notes
            )
            repository.insertBills(listOf(newBill))
            
            // Recalculate contract state
            recalculateContractState(saleId)
            
            try {
                val updatedBills = repository.getBillsBySaleId(saleId).first()
                val latestPaidBill = updatedBills.filter { it.isPaid }.maxByOrNull { it.id } ?: newBill
                val customer = repository.getCustomerById(customerId)
                
                pendingPaymentBill = latestPaidBill
                pendingPaymentSale = sale
                pendingPaymentCustomer = customer
                pendingPaymentAllBills = updatedBills
            } catch (e: Exception) {
                android.util.Log.e("MainViewModel", "Error setting pending payment print state", e)
            }
            
            onSuccess()
        }
    }

    fun deletePayment(bill: InstallmentBill) {
        viewModelScope.launch {
            repository.deleteBill(bill)
            recalculateContractState(bill.saleId)
        }
    }

    fun editPayment(bill: InstallmentBill, newAmount: Double, newDate: String, newNotes: String, onError: (String) -> Unit, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val sale = repository.getSaleById(bill.saleId) ?: return@launch
            val bills = repository.getBillsBySaleId(bill.saleId).first()
            
            // Other paid bills (excluding the one being edited)
            val otherPaidBills = bills.filter { it.isPaid && it.id != bill.id }
            val totalPaidOthers = otherPaidBills.sumOf { it.amountPaid }
            val remainingBeforeThis = sale.installmentPrice - totalPaidOthers
            
            if (newAmount > remainingBeforeThis) {
                onError("قيمة الدفعة أكبر من المبلغ المتبقي")
                return@launch
            }
            
            val updatedBill = bill.copy(
                amount = newAmount,
                amountPaid = newAmount,
                paymentDate = newDate,
                dueDate = newDate,
                notes = newNotes
            )
            repository.updateBill(updatedBill)
            
            recalculateContractState(bill.saleId)
            onSuccess()
        }
    }

    private suspend fun recalculateContractState(saleId: Long) {
        val sale = repository.getSaleById(saleId) ?: return
        val allBills = repository.getBillsBySaleId(saleId).first()
        
        // 1. Filter paid bills
        val paidBills = allBills.filter { it.isPaid }.sortedBy { it.paymentDate ?: it.dueDate }
        
        // 2. Delete all unpaid bills (the single unpaid due tracker will be re-created)
        val unpaidBills = allBills.filter { !it.isPaid }
        unpaidBills.forEach { repository.deleteBill(it) }
        
        // 3. Compute sums
        val totalPaid = paidBills.sumOf { it.amountPaid }
        val remaining = sale.installmentPrice - totalPaid
        
        if (remaining <= 0.0) {
            repository.updateSale(sale.copy(status = "COMPLETED"))
        } else {
            repository.updateSale(sale.copy(status = "ACTIVE"))
            
            // Count subsequent payments (excluding down payment)
            val subsequentPayments = paidBills.filter { !it.notes.contains("الدفعة الأولى") && !it.notes.contains("مقدم") }
            val nextDueDate = if (subsequentPayments.isEmpty()) {
                sale.firstDueDate
            } else {
                val lastPayment = subsequentPayments.last()
                val lastPaymentDateStr = lastPayment.paymentDate ?: lastPayment.dueDate
                addOneMonth(lastPaymentDateStr)
            }
            
            // Create a single unpaid bill representing the next due date
            val nextUnpaidBill = InstallmentBill(
                saleId = saleId,
                customerId = sale.customerId,
                billNumber = paidBills.size + 1,
                dueDate = nextDueDate,
                amount = remaining,
                amountPaid = 0.0,
                paymentDate = null,
                isPaid = false,
                notes = "المتبقي المستحق"
            )
            repository.insertBills(listOf(nextUnpaidBill))
        }
    }

    private fun addOneMonth(dateStr: String): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        try {
            val date = sdf.parse(dateStr)
            if (date != null) {
                cal.time = date
                cal.add(Calendar.MONTH, 1)
                return sdf.format(cal.time)
            }
        } catch (e: Exception) {
            // fallback
        }
        return dateStr
    }


    // ==========================================
    // EXPORT / IMPORT ZIP BACKUPS
    // ==========================================
    fun exportBackup(context: Context, onSuccess: (File) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                // Close DB connection safely
                db.close()
                val dbFile = context.getDatabasePath("sales_installments_db")
                val backupZipFile = File(context.cacheDir, "sales_backup.zip")
                
                ZipOutputStream(FileOutputStream(backupZipFile)).use { zos ->
                    if (dbFile.exists()) {
                        zos.putNextEntry(ZipEntry("sales_installments_db"))
                        FileInputStream(dbFile).use { fis ->
                            fis.copyTo(zos)
                        }
                        zos.closeEntry()
                    }
                    // Include -wal and -shm if they exist
                    val walFile = File(dbFile.path + "-wal")
                    if (walFile.exists()) {
                        zos.putNextEntry(ZipEntry("sales_installments_db-wal"))
                        FileInputStream(walFile).use { fis -> fis.copyTo(zos) }
                        zos.closeEntry()
                    }
                    val shmFile = File(dbFile.path + "-shm")
                    if (shmFile.exists()) {
                        zos.putNextEntry(ZipEntry("sales_installments_db-shm"))
                        FileInputStream(shmFile).use { fis -> fis.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
                
                // Reopen database
                AppDatabase.getDatabase(context)
                onSuccess(backupZipFile)
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "حدث خطأ أثناء تصدير النسخة الاحتياطية")
            }
        }
    }

    fun importBackup(context: Context, zipFile: File, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                db.close()
                val dbFile = context.getDatabasePath("sales_installments_db")
                
                ZipInputStream(FileInputStream(zipFile)).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val targetFile = File(dbFile.parentFile, entry.name)
                        FileOutputStream(targetFile).use { fos ->
                            zis.copyTo(fos)
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }

                // Reopen database
                AppDatabase.getDatabase(context)
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "حدث خطأ أثناء استيراد النسخة الاحتياطية")
            }
        }
    }
}

data class DashboardStats(
    val overdueCount: Int = 0,
    val dueTodayCount: Int = 0,
    val upcomingCount: Int = 0,
    val totalSales: Double = 0.0,
    val totalProfits: Double = 0.0
)
