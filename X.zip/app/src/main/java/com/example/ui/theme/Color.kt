package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors - Premium Brand
val DeepNavy = Color(0xFF071D49)
val RoyalGold = Color(0xFFD4A937)

// UI Accent/Status Colors
val SuccessGreen = Color(0xFF16A34A)
val WarningAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFDC2626)

// Surface and Background - Pure White Main Background
val SoftBackground = Color(0xFFFFFFFF)
val SoftSurface = Color(0xFFFFFFFF)
val GrayLight = Color(0xFFF6F8FB)

// Typography & Borders
val TextDark = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)
val DividerLight = Color(0xFFF1F5F9)

