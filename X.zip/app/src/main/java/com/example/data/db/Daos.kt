package com.example.data.db

import androidx.room.*
import com.example.data.model.Customer
import com.example.data.model.InstallmentBill
import com.example.data.model.Sale
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY id DESC")
    fun getAllCustomers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: Long): Customer?

    @Query("SELECT * FROM customers WHERE id = :id")
    fun getCustomerByIdFlow(id: Long): Flow<Customer?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer): Long

    @Update
    suspend fun updateCustomer(customer: Customer)

    @Delete
    suspend fun deleteCustomer(customer: Customer)
}

@Dao
interface SaleDao {
    @Query("SELECT * FROM sales ORDER BY id DESC")
    fun getAllSales(): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE id = :id LIMIT 1")
    suspend fun getSaleById(id: Long): Sale?

    @Query("SELECT * FROM sales WHERE customerId = :customerId")
    fun getSalesByCustomerId(customerId: Long): Flow<List<Sale>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: Sale): Long

    @Update
    suspend fun updateSale(sale: Sale)

    @Delete
    suspend fun deleteSale(sale: Sale)
}

@Dao
interface InstallmentBillDao {
    @Query("SELECT * FROM installment_bills ORDER BY dueDate ASC")
    fun getAllBills(): Flow<List<InstallmentBill>>

    @Query("SELECT * FROM installment_bills WHERE saleId = :saleId ORDER BY billNumber ASC")
    fun getBillsBySaleId(saleId: Long): Flow<List<InstallmentBill>>

    @Query("SELECT * FROM installment_bills WHERE customerId = :customerId ORDER BY dueDate ASC")
    fun getBillsByCustomerId(customerId: Long): Flow<List<InstallmentBill>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBills(bills: List<InstallmentBill>)

    @Update
    suspend fun updateBill(bill: InstallmentBill)

    @Delete
    suspend fun deleteBill(bill: InstallmentBill)

    @Query("DELETE FROM installment_bills WHERE saleId = :saleId")
    suspend fun deleteBillsBySaleId(saleId: Long)
}
