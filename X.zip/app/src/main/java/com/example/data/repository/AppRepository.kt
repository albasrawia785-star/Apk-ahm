package com.example.data.repository

import com.example.data.db.CustomerDao
import com.example.data.db.InstallmentBillDao
import com.example.data.db.SaleDao
import com.example.data.model.Customer
import com.example.data.model.InstallmentBill
import com.example.data.model.Sale
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.*

class AppRepository(
    private val customerDao: CustomerDao,
    private val saleDao: SaleDao,
    private val installmentBillDao: InstallmentBillDao
) {
    fun getAllCustomers(): Flow<List<Customer>> = customerDao.getAllCustomers()
    suspend fun getCustomerById(id: Long): Customer? = customerDao.getCustomerById(id)
    fun getCustomerByIdFlow(id: Long): Flow<Customer?> = customerDao.getCustomerByIdFlow(id)
    suspend fun insertCustomer(customer: Customer): Long = customerDao.insertCustomer(customer)
    suspend fun updateCustomer(customer: Customer) = customerDao.updateCustomer(customer)
    suspend fun deleteCustomer(customer: Customer) = customerDao.deleteCustomer(customer)

    fun getAllSales(): Flow<List<Sale>> = saleDao.getAllSales()
    suspend fun getSaleById(id: Long): Sale? = saleDao.getSaleById(id)
    fun getSalesByCustomerId(customerId: Long): Flow<List<Sale>> = saleDao.getSalesByCustomerId(customerId)
    
    suspend fun insertSale(sale: Sale, bills: List<InstallmentBill>): Long {
        val saleId = saleDao.insertSale(sale)
        val updatedBills = bills.map { it.copy(saleId = saleId) }
        installmentBillDao.insertBills(updatedBills)
        return saleId
    }
    
    suspend fun updateSale(sale: Sale) = saleDao.updateSale(sale)
    suspend fun deleteSale(sale: Sale) {
        saleDao.deleteSale(sale)
        installmentBillDao.deleteBillsBySaleId(sale.id)
    }

    fun getAllBills(): Flow<List<InstallmentBill>> = installmentBillDao.getAllBills()
    fun getBillsBySaleId(saleId: Long): Flow<List<InstallmentBill>> = installmentBillDao.getBillsBySaleId(saleId)
    fun getBillsByCustomerId(customerId: Long): Flow<List<InstallmentBill>> = installmentBillDao.getBillsByCustomerId(customerId)
    suspend fun updateBill(bill: InstallmentBill) = installmentBillDao.updateBill(bill)
    suspend fun insertBills(bills: List<InstallmentBill>) = installmentBillDao.insertBills(bills)
    suspend fun deleteBill(bill: InstallmentBill) = installmentBillDao.deleteBill(bill)
    suspend fun deleteBillsBySaleId(saleId: Long) = installmentBillDao.deleteBillsBySaleId(saleId)

    // Prepopulate database with premium sample data if empty
    suspend fun prepopulateIfEmpty() {
        val currentCustomers = customerDao.getAllCustomers().first()
        if (currentCustomers.isNotEmpty()) return

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()

        // 1. Add premium customers
        val c1 = Customer(
            name = "حسن جمال الخفاجي",
            phone = "07712345678",
            job = "مهندس برمجيات",
            nationalId = "1994123456",
            province = "البصرة",
            nearestLandmark = "قرب ساحة سعد",
            registrationDate = sdf.format(cal.time),
            hasGuarantor = true,
            guarantorName = "أحمد جمال الخفاجي",
            guarantorPhone = "07787654321",
            guarantorJob = "طبيب أسنان",
            guarantorNationalId = "1992987654"
        )
        val cid1 = customerDao.insertCustomer(c1)

        val c2 = Customer(
            name = "علي محمد العراقي",
            phone = "07801122334",
            job = "مدرس ثانوي",
            nationalId = "1988556677",
            province = "بغداد",
            nearestLandmark = "شارع فلسطين - قرب المول",
            registrationDate = sdf.format(cal.time),
            hasGuarantor = false
        )
        val cid2 = customerDao.insertCustomer(c2)

        val c3 = Customer(
            name = "سارة خالد الجبوري",
            phone = "07901122335",
            job = "طبيبة أطفال",
            nationalId = "1991443322",
            province = "نينوى",
            nearestLandmark = "حي الزهور - قرب جامع الكبير",
            registrationDate = sdf.format(cal.time),
            hasGuarantor = true,
            guarantorName = "خالد محمود الجبوري",
            guarantorPhone = "07909876543",
            guarantorJob = "مهندس متقاعد",
            guarantorNationalId = "1960221144"
        )
        val cid3 = customerDao.insertCustomer(c3)

        val c4 = Customer(
            name = "محمد أحمد الدليمي",
            phone = "07505544332",
            job = "أستاذ جامعي",
            nationalId = "1983445566",
            province = "الأنبار",
            nearestLandmark = "حي المعلمين - قرب المستشفى العام",
            registrationDate = sdf.format(cal.time),
            hasGuarantor = false
        )
        val cid4 = customerDao.insertCustomer(c4)

        // 2. Add sales and bills
        // Sale 1: Overdue
        cal.add(Calendar.MONTH, -2)
        val s1 = Sale(
            customerId = cid1,
            itemName = "آيفون 15 برو ماكس",
            itemDescription = "سعة 256 جيجابايت، لون تيتانيوم طبيعي",
            cashPrice = 1200000.0,
            installmentPrice = 1500000.0,
            downPayment = 300000.0,
            monthsCount = 0,
            monthlyInstallment = 0.0,
            dueDay = 15,
            firstDueDate = sdf.format(cal.time),
            saleDate = sdf.format(cal.time),
            status = "ACTIVE"
        )
        val sid1 = saleDao.insertSale(s1)
        val bills1 = listOf(
            InstallmentBill(
                saleId = sid1,
                customerId = cid1,
                billNumber = 1,
                dueDate = sdf.format(cal.time),
                amount = 300000.0,
                amountPaid = 300000.0,
                paymentDate = sdf.format(cal.time),
                isPaid = true,
                notes = "الدفعة الأولى (مقدم العقد)"
            ),
            InstallmentBill(
                saleId = sid1,
                customerId = cid1,
                billNumber = 2,
                dueDate = sdf.format(cal.time),
                amount = 1200000.0,
                amountPaid = 0.0,
                paymentDate = null,
                isPaid = false,
                notes = "المتبقي المستحق"
            )
        )
        installmentBillDao.insertBills(bills1)

        // Sale 2: Due Today
        val sale2Cal = Calendar.getInstance()
        val s2 = Sale(
            customerId = cid2,
            itemName = "شاشة سامسونج ذكية 55 بوصة",
            itemDescription = "دقة 4K UHD، مع نظام تايزن",
            cashPrice = 450000.0,
            installmentPrice = 600000.0,
            downPayment = 120000.0,
            monthsCount = 0,
            monthlyInstallment = 0.0,
            dueDay = sale2Cal.get(Calendar.DAY_OF_MONTH),
            firstDueDate = sdf.format(sale2Cal.time),
            saleDate = sdf.format(sale2Cal.time),
            status = "ACTIVE"
        )
        val sid2 = saleDao.insertSale(s2)
        val bills2 = listOf(
            InstallmentBill(
                saleId = sid2,
                customerId = cid2,
                billNumber = 1,
                dueDate = sdf.format(sale2Cal.time),
                amount = 120000.0,
                amountPaid = 120000.0,
                paymentDate = sdf.format(sale2Cal.time),
                isPaid = true,
                notes = "الدفعة الأولى (مقدم العقد)"
            ),
            InstallmentBill(
                saleId = sid2,
                customerId = cid2,
                billNumber = 2,
                dueDate = sdf.format(sale2Cal.time),
                amount = 480000.0,
                amountPaid = 0.0,
                paymentDate = null,
                isPaid = false,
                notes = "المتبقي المستحق"
            )
        )
        installmentBillDao.insertBills(bills2)

        // Sale 3: Near Due
        val sale3Cal = Calendar.getInstance()
        val due3Cal = Calendar.getInstance()
        due3Cal.add(Calendar.DAY_OF_YEAR, 3)
        val s3 = Sale(
            customerId = cid3,
            itemName = "جهاز ماك بوك إير M2",
            itemDescription = "ذاكرة 8 جيجابايت، تخزين 256 جيجابايت",
            cashPrice = 1600000.0,
            installmentPrice = 2000000.0,
            downPayment = 500000.0,
            monthsCount = 0,
            monthlyInstallment = 0.0,
            dueDay = due3Cal.get(Calendar.DAY_OF_MONTH),
            firstDueDate = sdf.format(due3Cal.time),
            saleDate = sdf.format(sale3Cal.time),
            status = "ACTIVE"
        )
        val sid3 = saleDao.insertSale(s3)
        val bills3 = listOf(
            InstallmentBill(
                saleId = sid3,
                customerId = cid3,
                billNumber = 1,
                dueDate = sdf.format(sale3Cal.time),
                amount = 500000.0,
                amountPaid = 500000.0,
                paymentDate = sdf.format(sale3Cal.time),
                isPaid = true,
                notes = "الدفعة الأولى (مقدم العقد)"
            ),
            InstallmentBill(
                saleId = sid3,
                customerId = cid3,
                billNumber = 2,
                dueDate = sdf.format(due3Cal.time),
                amount = 1500000.0,
                amountPaid = 0.0,
                paymentDate = null,
                isPaid = false,
                notes = "المتبقي المستحق"
            )
        )
        installmentBillDao.insertBills(bills3)
    }
}
